# PAKET ARTEFAK — Assignment II DataCo (COMP8035041)

Paket ini disertakan agar hasil pada laporan dapat diperiksa ulang secara independen, bukan hanya konsisten di dalam PDF.

## 1. `analisis-lanjutan/`

| Berkas | Isi |
|---|---|
| `B_decision.json` | Keputusan top-k: cutoff persentil, jumlah terpilih, precision, lift, TP/FP, bootstrap 1.000 sampel |
| `C_ablation.json` | Uji kategori saja (AP 0,5766; ROC-AUC 0,5000) |
| `F_main.json` | Hasil utama eksperimen |
| `G_ablation_schedule.json`, `H_graph.json` | Artefak analisis lanjutan dan graf |
| `probs_sklearn_{val,test}.npy`, `probs_spark_{val,test}.npy` | Larik probabilitas per observasi (dasar Tabel 5.8) |
| `labels.json` | Label validation (5.028) dan test (8.043) |
| `SHA256SUMS.txt` | Checksum artefak analisis (5 entri, terverifikasi) |
| `I_pr_roc_main.png`, `H_projection_fixed.png`, `graph-subset-crop.png` | Gambar pendukung |

Catatan penting: larik probabilitas **test** pada `probs_sklearn_test.npy` (baris 0) menghasilkan AP 0,7364243228, sama persis dengan bukti eksekusi Colab; larik **validation** berasal dari eksekusi analisis yang berbeda dan tidak dipakai untuk angka final.

## 2. `eksekusi-final-lokal/run-actual/`

- `config.json`, `feature-contract.json`, `thresholds-frozen.json`, `environment.json` — konfigurasi, kosakata fitur, ambang beku, dan versi library eksekusi lokal (Python 3.12.15; scikit-learn 1.9.1; PySpark 3.5.9; NetworkX 3.7; NumPy 2.5.4; pandas 3.0.6; SciPy 1.18.1; Java 17.0.20.1).
- `metrics.json`, `metrics.csv` — metrik per model dan partisi.
- `predictions-<partisi>-<model>.csv` — prediksi per `Order Id` (8.043 baris test, 5.028 baris validation) berisi `probability_1`, `threshold`, `prediction`.
- `split.csv`, `orders.csv`, `audit-orders.json` — pembagian temporal dan kohort 62.897 pesanan.
- `graph-*.csv`, `graph-summary.json` — statistik graf: 62.948 node, 152.676 edge, 19 komponen.
- `sklearn-parameters.json`, `spark-parameters.json`, `convergence.json` — parameter dan riwayat konvergensi.
- `requirements-observed.txt`, `data-manifest.json`, `execution.log`, `status.json` — lingkungan, manifest data, dan log eksekusi.
- `sklearn-model.joblib`, `spark-model/` — model tersimpan.

## 3. `colab-final/evidence-colab-final-2026-10-22.json`

Bukti eksekusi Colab: Python 3.13.16, Spark 4.0.4, SHA-256 dataset `fa6d022e…80aa6` (95.910.149 byte), kohort, ambang validation, dan metrik final.

Keterbatasan yang tetap berlaku: versi scikit-learn, NetworkX, NumPy, dan pandas pada eksekusi Colab **tidak tercatat** di artefak mana pun.

## 4. `notebook/Assignment-II-DataCo-executed-local.ipynb`

Notebook eksekusi lokal 20 Oktober 2026, dipakai sebagai pemeriksaan reproduktibilitas.

## 5. Hubungan dengan laporan

- Tabel 5.5 dan 5.6 bersumber dari bukti eksekusi Colab; nilainya cocok sampai enam angka desimal.
- Tabel 5.8 memakai larik probabilitas test Colab dan berkas prediksi lokal untuk baris validation.
- Seluruh confusion matrix, AP, ROC-AUC, precision, recall, dan F1 dapat dihitung ulang dari berkas prediksi; hasilnya identik dengan `metrics.json`.

Checksum setiap berkas di dalam paket tercatat pada `SHA256SUMS-PAKET.txt`.
